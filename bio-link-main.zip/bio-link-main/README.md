# Link-in-bio

Simple static HTML website for link-in-bio page.

# Technology

- HTML, CSS and JavaScript
- [Vanta.js](https://www.vantajs.com/)

## Template used from [this](https://github.com/craftzdog/link-in-bio) repo by [craftzdog](https://github.com/craftzdog)

## License

MIT by Anurag Pramanik
